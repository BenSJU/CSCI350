#include "types.h"
#include "stat.h"
#include "user.h"
//#include <stdio.h>

char buf[10];

int main(int argc, char *argv[])
{
  int readcount = getreadcount();
  read(1, buf, 1);
  printf(1, "Read count: %d\n", readcount);

  exit();
}
