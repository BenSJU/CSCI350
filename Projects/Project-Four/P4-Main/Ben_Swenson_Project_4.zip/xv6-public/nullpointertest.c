#include "types.h"
#include "user.h"

int
main(int argc, char *argv[])
{

  int *x = 0;

  printf(1, "thing pointed to by x, should crash %d\n", x[0]);
  printf(1, "address of main %p\n", &main);

  //int* vals = malloc(10 * sizeof(int));

  //reading and writing to allocated memory should succeed
  // vals[0] = 1337;
  // vals[1] = vals[0];

  //uncomment one of the three blocks below to test systems calls
/*
  //read-protect the memory
  //(NOTE: read-protects the entire first page of the heap)
  int res1 = mrprotect(vals);
  if (res1 != 0)
  {
    printf(1, "Failed to read protect the memory\n");
  }

  //read should fail
  printf(2, "%d\n", vals[1]);
  printf(2, "ERROR IN PROJECT 4 IMPLEMENTATION: Read should have failed\n");
*/

/*
  //write-protext the memory
  //(NOTE: write-protects the entire first page of the heap)
  int res2 = mwprotect(vals);
  if (res2 != 0)
    printf(1, "Failed to write protect the memory\n");

  // read should still succeed
  int test = vals[1];
  printf(2, "%d\n", vals[1]);
  printf(2, "Read OK\n");
  test++; //avoids "unused variable" compiler error

  //write should fail
  vals[1] = 867;
  printf(2, "ERROR IN YOUR PROJECT 4 IMPLEMENTATION: Write should have failed\n");
*/

/*
  //unprotect should suceed, even if no protections are present yet

  int res3 = munprotect(vals);
  if (res3 != 0)
  {
    printf(1, "Failed to unprotect the already-accessible memory\n");
  }

  //now the real test begins

  res3 = mrprotect(vals);
  if (res3 != 0)
    printf(1, "Failed to read protect the memory\n");
  res3 = mwprotect(vals);
  if(res3 != 0)
    printf(1, "Failed to write protect the memory\n");
  res3 = munprotect(vals);
  if (res3 != 0)
    printf(1, "Failed to unprotect the memory\n");

  //reading and writing allocated memory should, once again, succeed
  vals[2] = 1337;
  vals[3] = vals[2];
  printf(2, "unprotect test PASSED\n");
*/

  exit();
}
